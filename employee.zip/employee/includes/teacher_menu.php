<?php
echo'<div class="table-responsive">
                  <table class="table"> ';

    echo '<tr><td><a href="teacher.php"><img src="images/home.png" alt="" /></a> </td> ';
	echo '<td><a href="create_test.php"><img src="images/add2.png" alt="" /></a></td>';
	echo '<td><a href="mytest.php" ><img src="images/mylist.png" alt="" /></a></td>';
	echo '<td><a href="doing_test.php"><img src="images/exam.png" title="دخول الاختبار" /></a></td>';
	echo '<td><a href="profile.php"><img src="images/profile.png" alt="" /></a></td>
	      <td><a href="logout.php"><img src="images/logout.png" alt="" /></a></td></tr>';

	echo '<tr ><td><a href="teacher.php">Control Panel</a> </td> ';
	echo '<td><a href="create_test.php">إنشاء اختبار جديد</a></td>';
	echo '<td><a href="mytest.php">اختباراتي</a></td>';
	echo '<td><a href="doing_test.php">دخول الاختبار</a></td>';
	echo '<td><a href="profile.php">الملف الشخصي</a></td>
	      <td><a href="logout.php">تسجيل الخروج</a></td></tr>';

	echo '</table></div>';

	?>
