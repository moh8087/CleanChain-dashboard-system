<?php
echo'<div class="table-responsive">
                  <table class="table"> ';

    echo '<tr><td><a href="cpanel.php"><img src="images/home.png" alt="" /></a> </td> ';
	echo '<td><a href="orders.php"><img src="images/search.png" title="Search" /></a></td>';
	echo '<td><a href="delegate.php"><img src="images/drivers.png" alt="" /></a></td>';
	echo '<td><a href="customers.php" ><img src="images/riders.png" alt="" /></a></td>';
	echo '<td><a href="static.php"><img src="images/static.png" title="Statistic" /></a></td>';
	echo '<td><a href="logout.php"><img src="images/logout.png" alt="" /></a></td></tr>';

	echo '<tr ><td><a href="cpanel.php">Home</a> </td> ';
	echo '<td><a href="orders.php">Orders</a></td>';
	echo '<td><a href="delegate.php">Employees</a></td>';
	echo '<td><a href="customers.php">Customers</a></td>';
	echo '<td><a href="static.php">Statistic</a></td>';
	echo '<td><a href="logout.php">Logout</a></td></tr>';

	echo '</table></div>';

	?>
