<?php
echo'<div class="table-responsive">
                  <table class="table"> ';

    echo '<tr><td><a href="cpanel.php"><img src="images/home.png" alt="" /></a> </td> ';
	echo '<td><a href="drivers.php"><img src="images/drivers.png" alt="" /></a></td>';
	echo '<td><a href="riders.php" ><img src="images/riders.png" alt="" /></a></td>';
	echo '<td><a href="search.php"><img src="images/search.png" title="دخول الاختبار" /></a></td>';
	echo '<td><a href="static.php"><img src="images/static.png" title="دخول الاختبار" /></a></td>';
	echo '<td><a href="bill.php"><img src="images/invoice.png" alt="" /></a></td>
	      <td><a href="logout.php"><img src="images/logout.png" alt="" /></a></td></tr>';

	echo '<tr ><td><a href="cpanel.php">الرئيسية</a> </td> ';
	echo '<td><a href="drivers.php">السائقين</a></td>';
	echo '<td><a href="riders.php">الركاب</a></td>';
	echo '<td><a href="search.php">بحث</a></td>';
	echo '<td><a href="static.php">احصائيات</a></td>';
	echo '<td><a href="bill.php">كشف حساب</a></td>
	      <td><a href="logout.php">تسجيل الخروج</a></td></tr>';

	echo '</table></div>';

	?>
